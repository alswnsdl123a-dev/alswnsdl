import { existsSync, statSync } from "fs";
import { readFile } from "fs/promises";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CANDIDATES = [
  path.join(process.cwd(), "public", "hidden-jeonnam.zip"),
  "/opt/cursor/artifacts/hidden_jeonnam_source.zip",
  "/tmp/hidden_jeonnam_source.zip",
];

function zipPath() {
  return CANDIDATES.find((file) => existsSync(file) && statSync(file).size > 1024);
}

export async function GET() {
  const file = zipPath();
  if (!file) {
    return new Response("zip not found", { status: 404 });
  }
  const data = await readFile(file);
  return new Response(data, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="hidden-jeonnam.zip"',
      "Content-Length": String(data.byteLength),
      "Cache-Control": "no-store",
    },
  });
}
