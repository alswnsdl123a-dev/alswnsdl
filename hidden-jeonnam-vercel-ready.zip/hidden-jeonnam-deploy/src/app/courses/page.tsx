import { Suspense } from "react";
import { CourseStudio } from "@/components/course-studio";

export default function CoursesPage() {
  return (
    <Suspense
      fallback={
        <div className="mx-auto max-w-[1400px] px-4 py-10 text-sm text-muted-foreground">
          …
        </div>
      }
    >
      <div className="relative z-[100000] min-h-0 flex-1 overflow-y-auto">
        <CourseStudio />
      </div>
    </Suspense>
  );
}
