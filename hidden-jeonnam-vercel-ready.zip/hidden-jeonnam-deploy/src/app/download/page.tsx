"use client";

import { Download } from "lucide-react";
import { useI18n } from "@/components/i18n-provider";

export default function DownloadPage() {
  const { t } = useI18n();

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto flex w-full max-w-lg flex-col gap-4 px-5 py-10">
        <p className="text-xs tracking-wide text-primary uppercase">{t("download")}</p>
        <h1 className="font-heading text-2xl font-semibold">{t("downloadTitle")}</h1>
        <p className="text-sm leading-relaxed text-muted-foreground">{t("downloadBody")}</p>
        <a
          href="/api/download"
          className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          <Download className="size-4" />
          {t("downloadButton")}
        </a>
      </div>
    </div>
  );
}
