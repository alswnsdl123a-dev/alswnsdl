import type { Metadata } from "next";
import { Noto_Sans_JP, Noto_Sans_KR, Noto_Sans_SC, Noto_Serif_KR } from "next/font/google";
import { I18nProvider } from "@/components/i18n-provider";
import { SiteHeader } from "@/components/site-header";
import "./globals.css";

const kr = Noto_Sans_KR({
  subsets: ["latin"],
  variable: "--font-kr",
  weight: ["400", "500", "700"],
});

const sc = Noto_Sans_SC({
  subsets: ["latin"],
  variable: "--font-sc",
  weight: ["400", "500", "700"],
});

const jp = Noto_Sans_JP({
  subsets: ["latin"],
  variable: "--font-jp",
  weight: ["400", "500", "700"],
});

const serif = Noto_Serif_KR({
  subsets: ["latin"],
  variable: "--font-serif",
  weight: ["600", "700"],
});

export const metadata: Metadata = {
  title: "남도의 숨은 길 | Hidden Jeonnam",
  description:
    "전라남도 22개 시·군의 숨은 관광 명소를 찾고, 취향에 맞는 여행 코스를 추천합니다.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="ko"
      className={`${kr.variable} ${sc.variable} ${jp.variable} ${serif.variable} h-full antialiased`}
    >
      <body className="flex h-dvh flex-col overflow-hidden">
        <I18nProvider>
          <SiteHeader />
          <main className="flex h-full min-h-0 flex-1 flex-col overflow-hidden">{children}</main>
        </I18nProvider>
      </body>
    </html>
  );
}
