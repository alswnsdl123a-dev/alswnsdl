import { ExploreApp } from "@/components/explore-app";

export default function Home() {
  return <ExploreApp />;
}
