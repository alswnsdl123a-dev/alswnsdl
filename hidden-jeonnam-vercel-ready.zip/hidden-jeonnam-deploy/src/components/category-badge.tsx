"use client";

import { Trees, UtensilsCrossed, Landmark, Footprints } from "lucide-react";
import { CATEGORIES, loc } from "@/lib/i18n";
import { useI18n } from "@/components/i18n-provider";
import { CATEGORY_SOFT, CATEGORY_COLORS } from "@/lib/colors";
import type { Category } from "@/lib/types";
import { cn } from "@/lib/utils";

const ICONS = {
  nature: Trees,
  food: UtensilsCrossed,
  history: Landmark,
  experience: Footprints,
};

export function CategoryBadge({
  category,
  className,
}: {
  category: Category;
  className?: string;
}) {
  const { locale } = useI18n();
  const meta = CATEGORIES.find((item) => item.id === category)!;
  const Icon = ICONS[category];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[0.7rem] font-medium",
        className,
      )}
      style={{
        background: CATEGORY_SOFT[category],
        color: CATEGORY_COLORS[category],
      }}
    >
      <Icon className="size-3" />
      {loc(meta.label, locale)}
    </span>
  );
}
