"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { CalendarDays, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PlaceCard } from "@/components/place-card";
import { PlaceSheet } from "@/components/place-sheet";
import { MapView } from "@/components/map-view";
import { CategoryBadge } from "@/components/category-badge";
import { useI18n } from "@/components/i18n-provider";
import { CATEGORIES, loc } from "@/lib/i18n";
import { FEATURED_COURSES } from "@/data/courses";
import { PLACE_MAP, PLACES } from "@/data/places";
import { REGIONS } from "@/data/regions";
import { recommendCourse } from "@/lib/recommend";
import type { Category, GeneratedCourse, RegionId } from "@/lib/types";
import { cn } from "@/lib/utils";

export function CourseStudio() {
  const { locale, t } = useI18n();
  const params = useSearchParams();
  const seed = params.get("seed");
  const seedPlace = seed ? PLACE_MAP[seed] : undefined;

  const [categories, setCategories] = useState<Category[]>(
    seedPlace?.categories.slice(0, 2) ?? ["nature"],
  );
  const [regionId, setRegionId] = useState<RegionId | "all">(
    seedPlace?.regionId ?? "all",
  );
  const [days, setDays] = useState<1 | 2 | 3>(2);
  const [course, setCourse] = useState<GeneratedCourse | null>(null);
  const [attempted, setAttempted] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(seed);
  const [sheetOpen, setSheetOpen] = useState(false);

  const selected = PLACES.find((place) => place.id === selectedId) ?? null;

  const coursePlaces = useMemo(
    () => course?.days.flatMap((day) => day.places) ?? [],
    [course],
  );

  function toggleCategory(id: Category) {
    setCategories((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id],
    );
  }

  function generate() {
    setAttempted(true);
    setCourse(recommendCourse({ categories, regionId, days }));
  }

  function showFeatured(id: string) {
    const featured = FEATURED_COURSES.find((item) => item.id === id);
    if (!featured) return;
    setCourse({
      title: featured.title,
      summary: featured.summary,
      days: featured.days.map((day) => ({
        day: day.day,
        theme: day.theme,
        places: day.placeIds.map((placeId) => PLACE_MAP[placeId]).filter(Boolean),
      })),
    });
    setCategories(featured.categories);
    setRegionId(featured.regionIds[0] ?? "all");
    setDays(featured.days.length as 1 | 2 | 3);
  }

  return (
    <div className="relative z-[100000] mx-auto flex w-full max-w-[1400px] flex-1 flex-col gap-6 px-4 py-5 sm:px-6">
      <section className="relative z-[100001] grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <Card className="pointer-events-auto bg-card/80">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-heading">
              <Sparkles className="size-4 text-primary" />
              {t("buildCourse")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">
                {t("taste")}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map((category) => {
                  const pressed = categories.includes(category.id);
                  return (
                    <Chip
                      key={category.id}
                      pressed={pressed}
                      onSelect={() => toggleCategory(category.id)}
                    >
                      {loc(category.label, locale)}
                    </Chip>
                  );
                })}
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">
                {t("regionCluster")}
              </p>
              <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                <Chip
                  pressed={regionId === "all"}
                  onSelect={() => setRegionId("all")}
                >
                  {t("anywhere")}
                </Chip>
                {REGIONS.map((region) => (
                  <Chip
                    key={region.id}
                    pressed={regionId === region.id}
                    onSelect={() => setRegionId(region.id)}
                  >
                    {loc(region.name, locale)}
                  </Chip>
                ))}
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-medium text-muted-foreground">
                {t("days")}
              </p>
              <div className="flex gap-1.5">
                {([1, 2, 3] as const).map((value) => (
                  <Chip
                    key={value}
                    pressed={days === value}
                    onSelect={() => setDays(value)}
                  >
                    {value === 1 ? t("day1") : value === 2 ? t("day2") : t("day3")}
                  </Chip>
                ))}
              </div>
            </div>
            <Chip
              pressed
              strong
              block
              onSelect={generate}
            >
              {t("generate")}
            </Chip>
          </CardContent>
        </Card>
        <div className="pointer-events-auto">
          <p className="mb-2 font-heading text-sm font-medium">{t("featured")}</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {FEATURED_COURSES.map((featured) => (
              <button
                key={featured.id}
                type="button"
                onPointerDown={(event) => {
                  if (event.button !== 0) return;
                  event.preventDefault();
                  event.stopPropagation();
                  showFeatured(featured.id);
                }}
                className="relative z-[100001] cursor-pointer rounded-xl bg-card p-3 text-left ring-1 ring-foreground/10 transition-colors hover:bg-primary/5 hover:ring-primary/40"
              >
                <p className="text-[0.7rem] text-primary">
                  {loc(featured.daysLabel, locale)}
                </p>
                <p className="font-heading font-semibold">
                  {loc(featured.title, locale)}
                </p>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                  {loc(featured.summary, locale)}
                </p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {featured.categories.map((category) => (
                    <CategoryBadge key={category} category={category} />
                  ))}
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {course ? (
        <section className="relative z-[100001] grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
          <div className="pointer-events-auto space-y-4">
            <div>
              <p className="text-xs tracking-wide text-primary uppercase">
                {t("yourCourse")}
              </p>
              <h2 className="font-heading text-2xl font-semibold">
                {loc(course.title, locale)}
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {loc(course.summary, locale)} · {coursePlaces.length}{" "}
                {t("courseStops")}
              </p>
            </div>
            {course.days.map((day) => (
              <div key={day.day} className="space-y-2">
                <p className="flex items-center gap-2 font-heading text-sm font-semibold">
                  <CalendarDays className="size-4 text-primary" />
                  {t("dayN")} {day.day}
                  <span className="font-sans text-xs font-normal text-muted-foreground">
                    {loc(day.theme, locale)}
                  </span>
                </p>
                {day.places.map((place, index) => (
                  <div key={place.id} className="flex gap-2">
                    <span className="mt-4 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-[0.7rem] text-primary-foreground">
                      {index + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <PlaceCard
                        place={place}
                        selected={place.id === selectedId}
                        onSelect={(id) => {
                          setSelectedId(id);
                          setSheetOpen(true);
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="relative z-0 isolate min-h-[50vh] overflow-hidden rounded-xl ring-1 ring-foreground/10 lg:sticky lg:top-20 lg:h-[calc(100dvh-7rem)]">
            <MapView
              places={coursePlaces}
              selectedId={selectedId}
              path={coursePlaces}
              onSelect={(id) => {
                setSelectedId(id);
                setSheetOpen(true);
              }}
            />
          </div>
        </section>
      ) : (
        <p className="text-sm text-muted-foreground">
          {attempted ? t("noCourse") : t("courseHint")}
        </p>
      )}

      <PlaceSheet
        place={selected}
        open={sheetOpen && !!selected}
        onOpenChange={setSheetOpen}
      />
    </div>
  );
}

function Chip({
  pressed,
  strong,
  block,
  children,
  onSelect,
}: {
  pressed?: boolean;
  strong?: boolean;
  block?: boolean;
  children: React.ReactNode;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.preventDefault();
        event.stopPropagation();
        onSelect();
      }}
      className={cn(
        "relative z-[100002] inline-flex h-8 shrink-0 cursor-pointer items-center rounded-full border px-3 text-xs font-medium",
        block && "h-10 w-full justify-center rounded-lg text-sm",
        strong || pressed
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-background hover:bg-muted",
      )}
    >
      {children}
    </button>
  );
}
