"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { LayoutList, Map as MapIcon } from "lucide-react";
import { FilterBar } from "@/components/filter-bar";
import { PlaceCard } from "@/components/place-card";
import { PlaceDetailPanel } from "@/components/place-detail-panel";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/i18n-provider";
import { PLACES } from "@/data/places";
import { REGION_MAP } from "@/data/regions";
import type { Category, RegionId } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ExploreApp() {
  const { t } = useI18n();
  const [search, setSearch] = useState("");
  const [regionId, setRegionId] = useState<RegionId | "all">("all");
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(PLACES[0]?.id ?? null);
  const [mobileView, setMobileView] = useState<"list" | "detail">("list");

  useEffect(() => {
    const fromUrl = new URLSearchParams(window.location.search).get("place");
    if (fromUrl && PLACES.some((place) => place.id === fromUrl)) {
      setSelectedId(fromUrl);
      setMobileView("detail");
    }
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return PLACES.filter((place) => {
      if (regionId !== "all" && place.regionId !== regionId) return false;
      if (
        categories.length &&
        !place.categories.some((category) => categories.includes(category))
      ) {
        return false;
      }
      if (!q) return true;
      const region = REGION_MAP[place.regionId];
      const haystack = [
        place.name,
        place.summary,
        place.description,
        place.tip,
        region.name,
      ]
        .flatMap((text) => [text.ko, text.en, text.zh, text.ja])
        .join(" ")
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [search, regionId, categories]);

  const selectedIdResolved = filtered.some((place) => place.id === selectedId)
    ? selectedId
    : (filtered[0]?.id ?? null);
  const selected = filtered.find((place) => place.id === selectedIdResolved) ?? null;

  const selectPlace = useCallback((id: string) => {
    setSelectedId(id);
    setMobileView("detail");
    const url = new URL(window.location.href);
    url.searchParams.set("place", id);
    window.history.replaceState(null, "", `${url.pathname}${url.search}`);
  }, []);

  return (
    <div className="grid h-full min-h-0 flex-1 grid-cols-1 overflow-hidden lg:grid-cols-[400px_minmax(0,1fr)] xl:grid-cols-[440px_minmax(0,1fr)]">
      <section className="relative z-[200] flex h-full min-h-0 flex-col bg-background px-4 pt-4 sm:px-6 lg:pt-5">
        <p className="mb-3 text-xs text-muted-foreground">
          {PLACES.length} {t("placesCount")} · 22 {t("regionsCount")}
        </p>
        <FilterBar
          search={search}
          onSearch={setSearch}
          regionId={regionId}
          onRegion={setRegionId}
          categories={categories}
          onCategories={setCategories}
          resultCount={filtered.length}
        />
        <div className="mt-3 flex gap-1 rounded-lg bg-muted p-1 lg:hidden">
          <Button
            variant={mobileView === "list" ? "secondary" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={() => setMobileView("list")}
          >
            <LayoutList className="size-3.5" />
            {t("list")}
          </Button>
          <Button
            variant={mobileView === "detail" ? "secondary" : "ghost"}
            size="sm"
            className="flex-1"
            onClick={() => setMobileView("detail")}
          >
            <MapIcon className="size-3.5" />
            {t("map")}
          </Button>
        </div>
        <div
          className={cn(
            "mt-3 min-h-0 flex-1 space-y-2 overflow-y-auto overscroll-contain pb-4",
            mobileView === "detail" && "hidden lg:block",
          )}
          onPointerDown={(event) => {
            if (event.button !== 0) return;
            const node = (event.target as HTMLElement | null)?.closest(
              "[data-place-id]",
            );
            const id = node?.getAttribute("data-place-id");
            if (id) selectPlace(id);
          }}
        >
          {filtered.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border bg-card/60 px-4 py-10 text-center">
              <p className="font-heading font-medium">{t("emptyTitle")}</p>
              <p className="mt-1 text-sm text-muted-foreground">{t("emptyBody")}</p>
            </div>
          ) : (
            filtered.map((place) => (
              <PlaceCard
                key={place.id}
                place={place}
                selected={place.id === selectedIdResolved}
                onSelect={selectPlace}
              />
            ))
          )}
        </div>
      </section>
      <section
        className={cn(
          "relative z-0 isolate flex h-full min-h-0 min-w-0 flex-col overflow-hidden lg:pr-4 lg:pt-5 lg:pb-4 xl:pr-6",
          mobileView === "list" && "hidden lg:flex",
        )}
      >
        <div className="h-full min-h-0 overflow-hidden bg-card lg:rounded-xl lg:ring-1 lg:ring-foreground/10">
          <PlaceDetailPanel
            key={selectedIdResolved ?? "empty"}
            place={selected}
            places={PLACES}
            onSelectPlace={selectPlace}
          />
        </div>
      </section>
    </div>
  );
}
