"use client";

import { Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/components/i18n-provider";
import { CATEGORIES, loc } from "@/lib/i18n";
import { REGIONS } from "@/data/regions";
import type { Category, RegionId } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Trees, UtensilsCrossed, Landmark, Footprints } from "lucide-react";

const ICONS = {
  nature: Trees,
  food: UtensilsCrossed,
  history: Landmark,
  experience: Footprints,
};

export function FilterBar({
  search,
  onSearch,
  regionId,
  onRegion,
  categories,
  onCategories,
  resultCount,
}: {
  search: string;
  onSearch: (value: string) => void;
  regionId: RegionId | "all";
  onRegion: (value: RegionId | "all") => void;
  categories: Category[];
  onCategories: (value: Category[]) => void;
  resultCount: number;
}) {
  const { locale, t } = useI18n();

  function toggleCategory(id: Category) {
    onCategories(
      categories.includes(id)
        ? categories.filter((item) => item !== id)
        : [...categories, id],
    );
  }

  const hasFilters = search || regionId !== "all" || categories.length > 0;

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="search"
          value={search}
          onChange={(event) => onSearch(event.target.value)}
          placeholder={t("searchPlaceholder")}
          className="h-10 w-full rounded-lg border border-input bg-card pr-3 pl-9 text-sm outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
        />
      </div>
      <div>
        <p className="mb-1.5 text-[0.7rem] font-medium tracking-wide text-muted-foreground uppercase">
          {t("categories")}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {CATEGORIES.map((category) => {
            const Icon = ICONS[category.id];
            const pressed = categories.includes(category.id);
            return (
              <button
                key={category.id}
                type="button"
                aria-pressed={pressed}
                onClick={() => toggleCategory(category.id)}
                className={cn(
                  "inline-flex h-8 items-center gap-1 rounded-full border border-border bg-card px-3 text-xs font-medium transition",
                  pressed && "border-primary bg-primary/10 text-primary",
                )}
              >
                <Icon className="size-3.5" />
                {loc(category.label, locale)}
              </button>
            );
          })}
        </div>
      </div>
      <div>
        <p className="mb-1.5 text-[0.7rem] font-medium tracking-wide text-muted-foreground uppercase">
          {t("region")}
        </p>
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <Button
            size="sm"
            variant={regionId === "all" ? "default" : "outline"}
            className="rounded-full"
            onClick={() => onRegion("all")}
          >
            {t("allRegions")}
          </Button>
          {REGIONS.map((region) => (
            <Button
              key={region.id}
              size="sm"
              variant={regionId === region.id ? "default" : "outline"}
              className="rounded-full"
              onClick={() => onRegion(region.id)}
            >
              {loc(region.name, locale)}
            </Button>
          ))}
        </div>
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {resultCount} {t("results")}
        </span>
        {hasFilters && (
          <button
            type="button"
            className="inline-flex items-center gap-1 text-primary"
            onClick={() => {
              onSearch("");
              onRegion("all");
              onCategories([]);
            }}
          >
            <X className="size-3" />
            {t("clearFilters")}
          </button>
        )}
      </div>
    </div>
  );
}
