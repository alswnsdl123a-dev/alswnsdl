"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { LocateFixed, Navigation, Search } from "lucide-react";
import { useI18n } from "@/components/i18n-provider";
import { loc } from "@/lib/i18n";
import { CATEGORY_COLORS, primaryCategory } from "@/lib/colors";
import { getKakaoJsKey, loadKakaoMaps } from "@/lib/kakao-loader";
import { JEONNAM_CENTER, REGION_MAP } from "@/data/regions";
import type { Locale, Place } from "@/lib/types";
import { cn } from "@/lib/utils";

type LatLng = { lat: number; lng: number };
type SearchHit = {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
};
type RouteResult = {
  distanceMeters: number;
  durationSeconds: number;
  path: LatLng[];
  provider: string;
};

function pinSvg(color: string, label: string) {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="44" viewBox="0 0 36 44">
      <path fill="${color}" d="M18 0C8.06 0 0 8.06 0 18c0 12.4 18 26 18 26s18-13.6 18-26C36 8.06 27.94 0 18 0z"/>
      <circle cx="18" cy="18" r="11" fill="#f7f1e8"/>
      <text x="18" y="22" text-anchor="middle" font-size="10" font-family="sans-serif" font-weight="700" fill="${color}">${label}</text>
    </svg>`,
  )}`;
}

function dotSvg(color: string) {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
      <circle cx="9" cy="9" r="7" fill="${color}" stroke="#f7f1e8" stroke-width="2"/>
    </svg>`,
  )}`;
}

function formatKm(meters: number, locale: Locale) {
  const km = meters / 1000;
  if (locale === "zh") return `${km.toFixed(1)}公里`;
  if (locale === "en") return `${km.toFixed(1)} km`;
  return `${km.toFixed(1)}km`;
}

function formatMinutes(seconds: number, locale: Locale) {
  const minutes = Math.max(1, Math.round(seconds / 60));
  if (locale === "ko") return `약 ${minutes}분`;
  if (locale === "zh") return `约${minutes}分钟`;
  if (locale === "ja") return `約${minutes}分`;
  return `${minutes} min`;
}

function pinLetter(kind: "origin" | "dest", locale: Locale) {
  if (kind === "origin") {
    return { ko: "출", en: "A", zh: "起", ja: "出" }[locale];
  }
  return { ko: "도", en: "B", zh: "终", ja: "着" }[locale];
}

function osmEmbed(lat: number, lng: number) {
  const pad = 0.06;
  return `https://www.openstreetmap.org/export/embed.html?bbox=${lng - pad}%2C${lat - pad}%2C${lng + pad}%2C${lat + pad}&layer=mapnik&marker=${lat}%2C${lng}`;
}

export default function KakaoMapPanel({
  places,
  selectedId,
  onSelect,
  onOpenDetail,
  path,
  locale,
  enableNavigation = false,
  compact = false,
}: {
  places: Place[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onOpenDetail?: (id: string) => void;
  locale: Locale;
  path?: Place[];
  enableNavigation?: boolean;
  compact?: boolean;
}) {
  const { t } = useI18n();
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<kakao.maps.Map | null>(null);
  const placeMarkersRef = useRef<kakao.maps.Marker[]>([]);
  const originMarkerRef = useRef<kakao.maps.Marker | null>(null);
  const destMarkerRef = useRef<kakao.maps.Marker | null>(null);
  const routeLineRef = useRef<kakao.maps.Polyline | null>(null);
  const courseLineRef = useRef<kakao.maps.Polyline | null>(null);
  const placesServiceRef = useRef<kakao.maps.services.Places | null>(null);

  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [origin, setOrigin] = useState<(LatLng & { label: string }) | null>(null);
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [searching, setSearching] = useState(false);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [route, setRoute] = useState<RouteResult | null>(null);
  const [routing, setRouting] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const autoLocateRef = useRef(false);

  const [originHost] = useState(() =>
    typeof window === "undefined" ? "" : window.location.origin,
  );
  const [waited, setWaited] = useState(false);

  const selected = places.find((place) => place.id === selectedId) ?? null;
  const hasKey = Boolean(getKakaoJsKey());

  const relayout = useCallback(() => {
    const map = mapRef.current;
    if (!map) return;
    map.relayout();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setWaited(true), 2500);
    return () => window.clearTimeout(timer);
  }, [hasKey]);

  useEffect(() => {
    if (!hasKey) return;
    let cancelled = false;
    let started = false;
    let created: kakao.maps.Map | null = null;

    const mount = () => {
      if (started || cancelled) return true;
      const node = containerRef.current;
      if (!node) return false;
      if (node.clientWidth < 16 || node.clientHeight < 16) return false;

      started = true;
      loadKakaoMaps()
        .then(() => {
          if (cancelled || !containerRef.current) return;
          const el = containerRef.current;
          el.replaceChildren();
          const kakaoMaps = window.kakao.maps;
          created = new kakaoMaps.Map(el, {
            center: new kakaoMaps.LatLng(JEONNAM_CENTER.lat, JEONNAM_CENTER.lng),
            level: 8,
          });
          mapRef.current = created;
          placesServiceRef.current = new kakaoMaps.services.Places();
          setLoadError(null);
          setReady(true);
          window.requestAnimationFrame(() => created?.relayout());
        })
        .catch(() => {
          if (!cancelled) {
            started = false;
            setLoadError("kakao-sdk-load-failed");
          }
        });
      return true;
    };

    const observer = new ResizeObserver(() => mount());
    if (containerRef.current) observer.observe(containerRef.current);
    const poll = window.setInterval(() => {
      if (mount() || cancelled) window.clearInterval(poll);
    }, 200);
    window.requestAnimationFrame(() => mount());

    return () => {
      cancelled = true;
      observer.disconnect();
      window.clearInterval(poll);
      placeMarkersRef.current.forEach((marker) => marker.setMap(null));
      placeMarkersRef.current = [];
      courseLineRef.current?.setMap(null);
      originMarkerRef.current?.setMap(null);
      destMarkerRef.current?.setMap(null);
      routeLineRef.current?.setMap(null);
      if (containerRef.current) containerRef.current.replaceChildren();
      mapRef.current = null;
      created = null;
    };
  }, [hasKey]);

  useEffect(() => {
    window.addEventListener("resize", relayout);
    return () => window.removeEventListener("resize", relayout);
  }, [relayout]);

  useEffect(() => {
    if (!ready || !containerRef.current) return;
    const observer = new ResizeObserver(() => relayout());
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [ready, relayout]);

  useEffect(() => {
    if (ready) relayout();
  }, [ready, selectedId, relayout]);

  const locate = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError(t("locationFailed"));
      return;
    }
    setLocating(true);
    setLocationError(null);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setOrigin({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          label: t("originHere"),
        });
        setLocating(false);
      },
      (error) => {
        setLocating(false);
        setLocationError(
          error.code === error.PERMISSION_DENIED
            ? t("locationDenied")
            : t("locationFailed"),
        );
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 30_000 },
    );
  }, [t]);

  useEffect(() => {
    if (
      enableNavigation &&
      selected &&
      !origin &&
      !locating &&
      !autoLocateRef.current
    ) {
      autoLocateRef.current = true;
      window.setTimeout(() => locate(), 0);
    }
  }, [enableNavigation, selected, origin, locating, locate]);

  useEffect(() => {
    if (!ready || !mapRef.current) return;
    const kakaoMaps = window.kakao.maps;
    const map = mapRef.current;
    placeMarkersRef.current.forEach((marker) => marker.setMap(null));
    placeMarkersRef.current = places
      .filter((place) => !(enableNavigation && place.id === selectedId))
      .map((place) => {
        const color = CATEGORY_COLORS[primaryCategory(place.categories)];
        const marker = new kakaoMaps.Marker({
          map,
          position: new kakaoMaps.LatLng(place.lat, place.lng),
          image: new kakaoMaps.MarkerImage(
            dotSvg(place.id === selectedId ? "#c45c26" : color),
            new kakaoMaps.Size(18, 18),
            { offset: new kakaoMaps.Point(9, 9) },
          ),
          title: loc(place.name, locale),
          zIndex: place.id === selectedId ? 4 : 1,
        });
        kakaoMaps.event.addListener(marker, "click", () => onSelect(place.id));
        return marker;
      });
  }, [ready, places, selectedId, locale, onSelect, enableNavigation]);

  useEffect(() => {
    if (!ready || !mapRef.current) return;
    const kakaoMaps = window.kakao.maps;
    const map = mapRef.current;
    courseLineRef.current?.setMap(null);
    if (path && path.length > 1) {
      courseLineRef.current = new kakaoMaps.Polyline({
        map,
        path: path.map((place) => new kakaoMaps.LatLng(place.lat, place.lng)),
        strokeWeight: 4,
        strokeColor: "#3d6b4f",
        strokeOpacity: 0.7,
        strokeStyle: "shortdash",
      });
    }
  }, [ready, path]);

  useEffect(() => {
    if (!ready || !mapRef.current) return;
    const kakaoMaps = window.kakao.maps;
    const map = mapRef.current;

    originMarkerRef.current?.setMap(null);
    destMarkerRef.current?.setMap(null);
    routeLineRef.current?.setMap(null);

    const showOrigin = Boolean(origin && enableNavigation);
    const showDest = Boolean(selected && enableNavigation);

    if (showOrigin && origin) {
      originMarkerRef.current = new kakaoMaps.Marker({
        map,
        position: new kakaoMaps.LatLng(origin.lat, origin.lng),
        image: new kakaoMaps.MarkerImage(
          pinSvg("#2f6f7e", pinLetter("origin", locale)),
          new kakaoMaps.Size(36, 44),
          { offset: new kakaoMaps.Point(18, 44) },
        ),
        zIndex: 8,
      });
    }
    if (showDest && selected) {
      destMarkerRef.current = new kakaoMaps.Marker({
        map,
        position: new kakaoMaps.LatLng(selected.lat, selected.lng),
        image: new kakaoMaps.MarkerImage(
          pinSvg("#c45c26", pinLetter("dest", locale)),
          new kakaoMaps.Size(36, 44),
          { offset: new kakaoMaps.Point(18, 44) },
        ),
        zIndex: 9,
      });
    }
    if (enableNavigation && origin && selected && route && route.path.length > 1) {
      routeLineRef.current = new kakaoMaps.Polyline({
        map,
        path: route.path.map((point) => new kakaoMaps.LatLng(point.lat, point.lng)),
        strokeWeight: 6,
        strokeColor: "#c45c26",
        strokeOpacity: 0.9,
        strokeStyle: "solid",
      });
    }

    const bounds = new kakaoMaps.LatLngBounds();
    if (showOrigin && origin) bounds.extend(new kakaoMaps.LatLng(origin.lat, origin.lng));
    if (selected) bounds.extend(new kakaoMaps.LatLng(selected.lat, selected.lng));
    if (showOrigin && origin && selected) {
      map.setBounds(bounds, 80, 48, 48, 48);
    } else if (selected) {
      map.setLevel(enableNavigation ? 7 : 8);
      map.panTo(new kakaoMaps.LatLng(selected.lat, selected.lng));
    } else if (showOrigin && origin) {
      map.setLevel(6);
      map.panTo(new kakaoMaps.LatLng(origin.lat, origin.lng));
    }
  }, [ready, origin, selected, route, locale, enableNavigation]);

  useEffect(() => {
    if (!enableNavigation || !origin || !selected) {
      return;
    }
    const controller = new AbortController();
    const params = new URLSearchParams({
      originLat: String(origin.lat),
      originLng: String(origin.lng),
      destLat: String(selected.lat),
      destLng: String(selected.lng),
    });
    const pending = window.setTimeout(() => setRouting(true), 0);
    fetch(`/api/directions?${params}`, { signal: controller.signal })
      .then((res) => res.json())
      .then((data: RouteResult) => {
        if (controller.signal.aborted) return;
        if (data?.path?.length) setRoute(data);
        else setRoute(null);
      })
      .catch(() => {
        if (!controller.signal.aborted) setRoute(null);
      })
      .finally(() => {
        if (!controller.signal.aborted) setRouting(false);
      });
    return () => {
      window.clearTimeout(pending);
      controller.abort();
    };
  }, [enableNavigation, origin, selected]);

  function searchPlaces(keyword: string) {
    setQuery(keyword);
    if (!placesServiceRef.current || keyword.trim().length < 2) {
      setHits([]);
      return;
    }
    setSearching(true);
    placesServiceRef.current.keywordSearch(
      keyword.trim(),
      (data, status) => {
        setSearching(false);
        if (status !== window.kakao.maps.services.Status.OK) {
          setHits([]);
          return;
        }
        setHits(
          data.slice(0, 6).map((item) => ({
            id: item.id,
            name: item.place_name,
            address: item.road_address_name || item.address_name,
            lat: Number(item.y),
            lng: Number(item.x),
          })),
        );
      },
      { size: 6 },
    );
  }

  function applySearchOrigin(hit: SearchHit) {
    setOrigin({ lat: hit.lat, lng: hit.lng, label: hit.name });
    setHits([]);
    setQuery(hit.name);
    setSearchOpen(false);
    setLocationError(null);
  }

  const destName = selected ? loc(selected.name, locale) : "";
  const kakaoLink =
    origin && selected
      ? `https://map.kakao.com/link/from/${encodeURIComponent(origin.label)},${origin.lat},${origin.lng}/to/${encodeURIComponent(destName)},${selected.lat},${selected.lng}`
      : selected
        ? `https://map.kakao.com/link/to/${encodeURIComponent(destName)},${selected.lat},${selected.lng}`
        : null;

  const showDomainHint = Boolean(hasKey && !ready && !loadError && waited);

  return (
    <div className="relative isolate h-full min-h-64 w-full overflow-hidden [contain:paint]">
      {!ready && selected && (
        <iframe
          key={selected.id}
          title={destName || "map"}
          className="absolute inset-0 z-0 h-full w-full border-0"
          src={osmEmbed(selected.lat, selected.lng)}
        />
      )}
      <div
        ref={containerRef}
        className={cn(
          "absolute inset-0 z-[1]",
          ready ? "bg-[#ebe4d6]" : "pointer-events-none opacity-0",
        )}
      />
      {!ready && !waited && hasKey && !loadError && (
        <div className="pointer-events-none absolute top-14 left-3 z-[2]">
          <p className="rounded-lg bg-card px-3 py-2 text-sm text-foreground shadow-sm">
            {t("loadingMap")}
          </p>
        </div>
      )}
      {(!hasKey || loadError) && (
        <div className="absolute inset-x-3 bottom-12 z-20 max-w-md rounded-xl border border-border bg-card/95 p-4 text-left shadow-sm">
          <p className="font-heading text-sm font-semibold text-foreground">
            {t("kakaoMissingTitle")}
          </p>
          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
            {t("kakaoMissingBody")}
          </p>
        </div>
      )}
      {showDomainHint && (
        <div className="pointer-events-none absolute inset-x-3 top-14 z-20 max-w-md rounded-xl border border-border bg-card/95 p-3 shadow-sm">
          <p className="font-heading text-sm font-semibold">{t("kakaoDomainTitle")}</p>
          <p className="mt-1 text-[0.7rem] leading-relaxed text-muted-foreground">
            {t("kakaoDomainBody")}
          </p>
          {originHost && (
            <p className="mt-2 rounded-md bg-muted px-2 py-1 font-mono text-[0.65rem] break-all">
              {originHost}
            </p>
          )}
        </div>
      )}
      {enableNavigation && hasKey && !loadError && !compact && (
        <>
          <div className="pointer-events-none absolute inset-x-3 top-3 z-10 flex flex-col gap-2">
            <div className="pointer-events-auto relative">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(event) => {
                  setSearchOpen(true);
                  searchPlaces(event.target.value);
                }}
                onFocus={() => setSearchOpen(true)}
                onBlur={() => window.setTimeout(() => setSearchOpen(false), 180)}
                placeholder={t("placeSearch")}
                className="h-10 w-full rounded-lg border border-border bg-card/95 pr-3 pl-9 text-sm shadow-sm outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
              />
              {searchOpen && query.trim().length >= 2 && (
                <ul className="absolute inset-x-0 top-[calc(100%+4px)] overflow-hidden rounded-lg border border-border bg-card shadow-lg">
                  {searching ? (
                    <li className="px-3 py-2 text-xs text-muted-foreground">
                      {t("routeLoading")}
                    </li>
                  ) : hits.length === 0 ? (
                    <li className="px-3 py-2 text-xs text-muted-foreground">
                      {t("placeSearchEmpty")}
                    </li>
                  ) : (
                    hits.map((hit) => (
                      <li key={hit.id}>
                        <button
                          type="button"
                          className="flex w-full flex-col items-start gap-0.5 px-3 py-2 text-left hover:bg-muted"
                          onMouseDown={(event) => event.preventDefault()}
                          onClick={() => applySearchOrigin(hit)}
                        >
                          <span className="text-sm font-medium">{hit.name}</span>
                          <span className="text-[0.7rem] text-muted-foreground">
                            {hit.address}
                          </span>
                          <span className="text-[0.7rem] text-primary">
                            {t("setAsOrigin")}
                          </span>
                        </button>
                      </li>
                    ))
                  )}
                </ul>
              )}
            </div>
            {!compact && (
            <div className="pointer-events-auto rounded-xl border border-border bg-card/95 p-3 text-sm shadow-sm">
              {selected ? (
                <>
                  <div className="grid gap-2">
                    <div className="flex items-start gap-2">
                      <span className="mt-0.5 rounded bg-[#2f6f7e] px-1.5 py-0.5 text-[0.65rem] font-semibold text-white">
                        {t("origin")}
                      </span>
                      <p className="min-w-0 leading-snug">
                        {origin?.label ?? (locating ? t("locating") : t("originHere"))}
                      </p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="mt-0.5 rounded bg-[#c45c26] px-1.5 py-0.5 text-[0.65rem] font-semibold text-white">
                        {t("destination")}
                      </span>
                      <p className="min-w-0 leading-snug">
                        {destName}
                        <span className="mt-0.5 block text-[0.7rem] text-muted-foreground">
                          {loc(REGION_MAP[selected.regionId].name, locale)}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    {routing && t("routeLoading")}
                    {!routing && route && (
                      <>
                        <span>
                          {t("distance")} {formatKm(route.distanceMeters, locale)}
                        </span>
                        <span>·</span>
                        <span>
                          {t("eta")} {formatMinutes(route.durationSeconds, locale)}
                        </span>
                      </>
                    )}
                    {!routing && !route && origin && t("routeFailed")}
                    {locationError && <span>{locationError}</span>}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {kakaoLink && (
                      <a
                        href={kakaoLink}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex h-8 items-center gap-1 rounded-lg bg-primary px-2.5 text-xs font-medium text-primary-foreground"
                      >
                        <Navigation className="size-3.5" />
                        {t("openKakaoNavi")}
                      </a>
                    )}
                    {onOpenDetail && (
                      <button
                        type="button"
                        onClick={() => onOpenDetail(selected.id)}
                        className="inline-flex h-8 items-center rounded-lg border border-border bg-background px-2.5 text-xs font-medium"
                      >
                        {t("openDetail")}
                      </button>
                    )}
                  </div>
                </>
              ) : (
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {t("pickPlaceHint")}
                </p>
              )}
            </div>
            )}
          </div>
        </>
      )}
      {enableNavigation && hasKey && !loadError && (
        <>
          <button
            type="button"
            onClick={locate}
            className={cn(
              "absolute right-3 bottom-3 z-10 inline-flex h-9 items-center gap-1.5 rounded-full border border-border bg-card px-3 text-xs font-medium shadow-sm",
              locating && "opacity-70",
            )}
          >
            <LocateFixed className="size-3.5" />
            {locating ? t("locating") : t("myLocation")}
          </button>
          {compact && selected && (
            <div className="pointer-events-none absolute bottom-3 left-3 z-10 max-w-[70%] rounded-lg bg-card/95 px-2 py-1 text-xs font-medium shadow-sm">
              {destName}
            </div>
          )}
        </>
      )}
    </div>
  );
}
