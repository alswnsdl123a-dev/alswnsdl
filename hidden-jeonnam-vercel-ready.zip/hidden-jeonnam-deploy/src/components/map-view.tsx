"use client";

import KakaoMapPanel from "@/components/kakao-map-panel";
import type { Place } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useI18n } from "@/components/i18n-provider";

export function MapView({
  places,
  selectedId,
  onSelect,
  onOpenDetail,
  path,
  enableNavigation = false,
  compact = false,
  className,
}: {
  places: Place[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onOpenDetail?: (id: string) => void;
  path?: Place[];
  enableNavigation?: boolean;
  compact?: boolean;
  className?: string;
}) {
  const { locale } = useI18n();
  return (
    <div className={cn("relative z-0 isolate h-full w-full overflow-hidden", className)}>
      <KakaoMapPanel
        places={places}
        selectedId={selectedId}
        onSelect={onSelect}
        onOpenDetail={onOpenDetail}
        locale={locale}
        path={path}
        enableNavigation={enableNavigation}
        compact={compact}
      />
    </div>
  );
}
