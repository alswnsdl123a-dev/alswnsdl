"use client";

import { useEffect } from "react";
import Image from "next/image";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { useI18n } from "@/components/i18n-provider";
import { loc } from "@/lib/i18n";
import { youtubeEmbedSrc, type GalleryItem } from "@/data/social";

export function MediaViewer({
  items,
  index,
  onClose,
  onIndex,
}: {
  items: GalleryItem[];
  index: number;
  onClose: () => void;
  onIndex: (index: number) => void;
}) {
  const { t, locale } = useI18n();
  const item = items[index];

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
      if (event.key === "ArrowRight") onIndex((index + 1) % items.length);
      if (event.key === "ArrowLeft") onIndex((index - 1 + items.length) % items.length);
    }
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [index, items.length, onClose, onIndex]);

  if (!item) return null;

  return (
    <div className="fixed inset-0 z-[300000] flex flex-col bg-black/92" role="dialog" aria-modal>
      <div className="flex shrink-0 items-center justify-between gap-3 px-4 py-3 text-white">
        <p className="min-w-0 truncate text-sm font-medium">
          {loc(item.alt, locale)}
          <span className="ml-2 text-white/60">
            {index + 1}/{items.length}
            {item.video ? ` · ${t("playVideo")}` : ` · ${t("viewPhoto")}`}
          </span>
        </p>
        <button
          type="button"
          onClick={onClose}
          className="inline-flex size-9 items-center justify-center rounded-full bg-white/10"
          aria-label={t("close")}
        >
          <X className="size-4" />
        </button>
      </div>
      <div className="relative flex min-h-0 flex-1 items-center justify-center px-12 pb-8">
        {item.video ? (
          <div
            className="aspect-video w-full max-w-4xl overflow-hidden rounded-xl bg-black"
            onClick={(event) => event.stopPropagation()}
          >
            <iframe
              title={loc(item.alt, locale)}
              src={youtubeEmbedSrc(item)}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="size-full border-0"
            />
          </div>
        ) : (
          <div className="relative h-full w-full max-w-5xl">
            <Image
              src={item.src}
              alt={loc(item.alt, locale)}
              fill
              className="object-contain"
              sizes="90vw"
              style={{ objectPosition: item.objectPosition }}
              priority
            />
          </div>
        )}
        <button
          type="button"
          onClick={() => onIndex((index - 1 + items.length) % items.length)}
          className="absolute left-3 inline-flex size-10 items-center justify-center rounded-full bg-white/15 text-white"
          aria-label={t("mediaPrev")}
        >
          <ChevronLeft className="size-5" />
        </button>
        <button
          type="button"
          onClick={() => onIndex((index + 1) % items.length)}
          className="absolute right-3 inline-flex size-10 items-center justify-center rounded-full bg-white/15 text-white"
          aria-label={t("mediaNext")}
        >
          <ChevronRight className="size-5" />
        </button>
      </div>
    </div>
  );
}
