"use client";

import Image from "next/image";
import { Clock, MapPin } from "lucide-react";
import { CategoryBadge } from "@/components/category-badge";
import { useI18n } from "@/components/i18n-provider";
import { loc } from "@/lib/i18n";
import { REGION_MAP } from "@/data/regions";
import type { Place } from "@/lib/types";
import { cn } from "@/lib/utils";

export function PlaceArt({
  place,
  className,
  sizes = "(min-width: 1024px) 55vw, 100vw",
  mode = "cover",
}: {
  place: Place;
  className?: string;
  sizes?: string;
  mode?: "cover" | "thumb";
}) {
  const { locale } = useI18n();
  return (
    <span className={cn("relative block overflow-hidden bg-muted", className)}>
      {mode === "thumb" ? (
        <Image
          src={`/places/${place.id}.jpg`}
          alt={loc(place.name, locale)}
          width={192}
          height={216}
          className="pointer-events-none h-full w-full object-cover"
        />
      ) : (
        <Image
          src={`/places/${place.id}.jpg`}
          alt={loc(place.name, locale)}
          fill
          className="pointer-events-none object-cover"
          sizes={sizes}
        />
      )}
    </span>
  );
}

export function PlaceCard({
  place,
  selected,
  onSelect,
}: {
  place: Place;
  selected?: boolean;
  onSelect: (id: string) => void;
}) {
  const { locale, t } = useI18n();
  const region = REGION_MAP[place.regionId];

  function choose() {
    onSelect(place.id);
  }

  return (
    <button
      type="button"
      data-place-id={place.id}
      aria-pressed={selected}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        choose();
      }}
      onClick={choose}
      className={cn(
        "relative isolate flex w-full cursor-pointer overflow-hidden rounded-xl bg-card text-left shadow-sm ring-1 ring-foreground/10 transition-colors hover:bg-primary/5 hover:ring-primary/50",
        selected && "bg-primary/5 ring-2 ring-primary",
      )}
    >
      <PlaceArt
        place={place}
        mode="thumb"
        className="relative h-24 w-20 shrink-0 sm:h-[6.75rem] sm:w-24"
      />
      <span className="block min-w-0 flex-1 p-3">
        <span className="flex items-start justify-between gap-2">
          <span className="block min-w-0">
            <span className="font-heading block text-[0.95rem] leading-snug font-semibold">
              {loc(place.name, locale)}
            </span>
            <span className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="size-3" />
              {loc(region.name, locale)}
            </span>
          </span>
          <span className="flex shrink-0 items-center gap-1 text-[0.7rem] text-muted-foreground">
            <Clock className="size-3" />
            {place.durationHours}
            {t("hours")}
          </span>
        </span>
        <span className="mt-1.5 line-clamp-2 block text-xs leading-relaxed text-muted-foreground">
          {loc(place.summary, locale)}
        </span>
        <span className="mt-2 flex flex-wrap gap-1">
          {place.categories.map((category) => (
            <CategoryBadge key={category} category={category} />
          ))}
        </span>
      </span>
    </button>
  );
}
