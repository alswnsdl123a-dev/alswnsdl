"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { ChevronRight, Clock, ExternalLink, MapPin, Play } from "lucide-react";
import { MapView } from "@/components/map-view";
import { CategoryBadge } from "@/components/category-badge";
import { PlaceArt } from "@/components/place-card";
import { MediaViewer } from "@/components/media-viewer";
import { useI18n } from "@/components/i18n-provider";
import { hiddennessLabel, loc } from "@/lib/i18n";
import {
  blogReviewsFor,
  galleryFor,
  reviewCounts,
  visitorReviewsFor,
  type GalleryItem,
} from "@/data/social";
import { PLACES } from "@/data/places";
import { REGION_MAP } from "@/data/regions";
import type { Place } from "@/lib/types";

function SectionHead({
  title,
  count,
}: {
  title: string;
  count?: number;
}) {
  return (
    <div className="flex items-center gap-1">
      <h3 className="text-[0.95rem] font-bold tracking-tight">
        {title}
        {typeof count === "number" && (
          <span className="ml-1 font-semibold text-muted-foreground">
            {count}
          </span>
        )}
      </h3>
      <ChevronRight className="size-4 text-muted-foreground" />
    </div>
  );
}

export function PlaceDetailPanel({
  place,
  places,
  onSelectPlace,
}: {
  place: Place | null;
  places: Place[];
  onSelectPlace: (id: string) => void;
}) {
  const { locale, t } = useI18n();
  const infoRef = useRef<HTMLDivElement>(null);
  const [mediaIndex, setMediaIndex] = useState<number | null>(null);
  const gallery = useMemo(() => (place ? galleryFor(place) : []), [place]);
  const blogs = useMemo(() => (place ? blogReviewsFor(place) : []), [place]);
  const visitors = useMemo(() => (place ? visitorReviewsFor(place) : []), [place]);
  const counts = place ? reviewCounts(place) : { blogs: 0, visitors: 0, photos: 0 };
  const visitorMedia: GalleryItem[] = place
    ? visitors.map((review, index) => ({
        src: review.thumb,
        alt: {
          ko: `${place.name.ko} 방문 사진 ${index + 1}`,
          en: `${place.name.en} photo ${index + 1}`,
          zh: `${place.name.zh} 访客照片 ${index + 1}`,
          ja: `${place.name.ja} 訪問写真 ${index + 1}`,
        },
        placeId: place.id,
      }))
    : [];

  useEffect(() => {
    infoRef.current?.scrollTo({ top: 0 });
    setMediaIndex(null);
  }, [place?.id]);

  if (!place) {
    return (
      <div className="flex size-full flex-col items-center justify-center bg-[#ebe4d6] px-8 text-center">
        <MapPin className="size-8 text-primary" />
        <p className="font-heading mt-3 text-lg font-semibold">{t("pickPlaceTitle")}</p>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">{t("pickPlaceBody")}</p>
      </div>
    );
  }

  const region = REGION_MAP[place.regionId];

  return (
    <div
      className="flex h-full min-h-0 flex-col overflow-hidden bg-card"
      data-selected-place={place.id}
    >
      <div className="relative h-48 min-h-48 shrink-0 sm:h-56 sm:min-h-56">
        <PlaceArt key={place.id} place={place} className="size-full" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/10 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-4 text-white sm:p-5">
          <p className="text-xs font-medium tracking-wide text-white/80 uppercase">
            {loc(region.name, locale)}
          </p>
          <h2 className="font-heading mt-0.5 text-2xl font-semibold drop-shadow-sm">
            {loc(place.name, locale)}
          </h2>
          <p className="mt-1 line-clamp-2 text-sm text-white/90">
            {loc(place.summary, locale)}
          </p>
        </div>
      </div>
      {PLACES.filter(
        (item) => item.regionId === place.regionId && item.id !== place.id,
      ).length > 0 && (
        <div className="shrink-0 border-b border-border px-3 py-2">
          <p className="mb-1.5 text-[0.7rem] font-medium text-muted-foreground">
            {t("nearbyPlaces")}
          </p>
          <div className="flex gap-1.5 overflow-x-auto pb-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {PLACES.filter(
              (item) => item.regionId === place.regionId && item.id !== place.id,
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onPointerDown={() => onSelectPlace(item.id)}
                className="shrink-0 rounded-full border border-border bg-background px-2.5 py-1 text-xs hover:border-primary hover:bg-primary/10"
              >
                {loc(item.name, locale)}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex shrink-0 items-center justify-between border-b border-border px-4 py-1.5">
        <p className="text-xs font-bold">{t("directions")}</p>
        <p className="truncate text-[0.7rem] text-muted-foreground">
          {loc(place.address, locale)}
        </p>
      </div>
      <section className="relative isolate h-64 min-h-64 shrink-0 overflow-hidden">
        <MapView
          places={places}
          selectedId={place.id}
          enableNavigation
          compact
          onSelect={onSelectPlace}
          className="h-64 w-full min-h-64"
        />
      </section>

      <div ref={infoRef} className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
        <div className="space-y-5 px-4 py-4 sm:px-5">
          <div className="flex flex-wrap gap-1">
            {place.categories.map((category) => (
              <CategoryBadge key={category} category={category} />
            ))}
          </div>
          <p className="text-sm leading-relaxed text-foreground/90">
            {loc(place.description, locale)}
          </p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-lg bg-muted/70 p-3">
              <p className="text-[0.7rem] text-muted-foreground">{t("hiddenness")}</p>
              <p className="mt-1 font-medium">{hiddennessLabel(place.hiddenness, locale)}</p>
            </div>
            <div className="rounded-lg bg-muted/70 p-3">
              <p className="text-[0.7rem] text-muted-foreground">{t("duration")}</p>
              <p className="mt-1 flex items-center gap-1 font-medium">
                <Clock className="size-3.5" />
                {place.durationHours}
                {t("hours")}
              </p>
            </div>
          </div>
          <p className="text-sm">
            <span className="text-xs text-muted-foreground">{t("address")}</span>
            <span className="mt-0.5 flex items-start gap-1">
              <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
              {loc(place.address, locale)}
            </span>
          </p>
          <p className="text-xs text-muted-foreground">
            {t("hoursLabel")} · {loc(place.hours, locale)}
          </p>

          <a
            href={`https://map.kakao.com/link/to/${encodeURIComponent(loc(place.name, locale))},${place.lat},${place.lng}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex h-9 items-center rounded-lg bg-primary px-3 text-xs font-medium text-primary-foreground"
          >
            {t("openKakaoNavi")}
          </a>

          <section className="space-y-2.5">
            <SectionHead title={t("visitorPhotos")} count={counts.photos} />
            <div className="grid grid-cols-3 gap-1.5">
              {gallery.map((item, index) => (
                <button
                  key={`${item.src}-${index}`}
                  type="button"
                  title={item.video ? t("playVideo") : t("viewPhoto")}
                  onClick={() => setMediaIndex(index)}
                  className="relative aspect-square overflow-hidden rounded-xl bg-muted"
                >
                  <Image
                    src={item.src}
                    alt={loc(item.alt, locale)}
                    fill
                    className="pointer-events-none object-cover"
                    sizes="(min-width: 1024px) 12vw, 30vw"
                    style={{ objectPosition: item.objectPosition }}
                  />
                  {item.video && (
                    <span className="absolute inset-0 flex items-center justify-center bg-black/25">
                      <span className="flex size-10 items-center justify-center rounded-full bg-black/70 text-white">
                        <Play className="size-4 fill-white" />
                      </span>
                    </span>
                  )}
                </button>
              ))}
            </div>
          </section>

          <section>
            <SectionHead title={t("blogReviews")} count={counts.blogs} />
            <ul className="mt-1 divide-y divide-border">
              {blogs.map((review) => (
                <li key={review.id}>
                  <a
                    href={review.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex gap-3 py-3 hover:bg-muted/40"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="relative size-6 overflow-hidden rounded-full bg-muted">
                          <Image
                            src={review.avatar}
                            alt=""
                            fill
                            className="object-cover"
                            sizes="24px"
                          />
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold">{review.author}</p>
                          <p className="truncate text-[0.7rem] text-muted-foreground">
                            {loc(review.bio, locale)}
                          </p>
                        </div>
                      </div>
                      <p className="mt-1.5 line-clamp-2 text-sm font-semibold leading-snug">
                        {loc(review.title, locale)}
                      </p>
                      <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                        {loc(review.excerpt, locale)}
                      </p>
                      <p className="mt-1.5 inline-flex items-center gap-1 text-[0.7rem] text-primary">
                        {loc(review.date, locale)}
                        <ExternalLink className="size-3" />
                        {t("openBlog")}
                      </p>
                    </div>
                    <div className="relative size-[4.75rem] shrink-0 overflow-hidden rounded-lg bg-muted sm:size-24">
                      <Image
                        src={review.thumb}
                        alt=""
                        fill
                        className="object-cover"
                        sizes="96px"
                      />
                      <span className="absolute right-1 bottom-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[0.65rem] font-medium text-white">
                        {review.photoCount}
                      </span>
                    </div>
                  </a>
                </li>
              ))}
            </ul>
          </section>

          <section className="pb-4">
            <SectionHead title={t("visitorReviews")} count={counts.visitors} />
            <ul className="mt-1 divide-y divide-border">
              {visitors.map((review, index) => (
                <li key={review.id} className="flex gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="relative size-6 overflow-hidden rounded-full bg-muted">
                        <Image
                          src={review.avatar}
                          alt=""
                          fill
                          className="object-cover"
                          sizes="24px"
                        />
                      </span>
                      <p className="text-sm font-semibold">{review.author}</p>
                      <p className="text-[0.7rem] text-muted-foreground">
                        {review.date} · {review.visit}
                        {t("nthVisit")}
                      </p>
                    </div>
                    <p className="mt-1.5 line-clamp-3 text-sm leading-relaxed">
                      {loc(review.body, locale)}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {review.tags.map((tag) => (
                        <span
                          key={tag.label.ko}
                          className="inline-flex items-center rounded-md bg-muted px-1.5 py-0.5 text-[0.7rem]"
                        >
                          {tag.emoji} {loc(tag.label, locale)}
                        </span>
                      ))}
                      <span className="inline-flex items-center rounded-md bg-muted px-1.5 py-0.5 text-[0.7rem] text-muted-foreground">
                        +{review.extraTags}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setMediaIndex(gallery.length + index)}
                    className="relative size-[4.75rem] shrink-0 overflow-hidden rounded-lg bg-muted sm:size-24"
                  >
                    <Image
                      src={review.thumb}
                      alt=""
                      fill
                      className="pointer-events-none object-cover"
                      sizes="96px"
                    />
                    <span className="absolute right-1 bottom-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[0.65rem] font-medium text-white">
                      {review.photoCount}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
      {mediaIndex !== null && (
        <MediaViewer
          items={[...gallery, ...visitorMedia]}
          index={mediaIndex}
          onClose={() => setMediaIndex(null)}
          onIndex={setMediaIndex}
        />
      )}
    </div>
  );
}
