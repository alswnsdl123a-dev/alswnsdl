"use client";

import Link from "next/link";
import { Clock, Lightbulb, MapPinned } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { buttonVariants } from "@/components/ui/button";
import { CategoryBadge } from "@/components/category-badge";
import { PlaceArt } from "@/components/place-card";
import { useI18n } from "@/components/i18n-provider";
import { hiddennessLabel, loc } from "@/lib/i18n";
import { REGION_MAP } from "@/data/regions";
import type { Place } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";

export function PlaceSheet({
  place,
  open,
  onOpenChange,
}: {
  place: Place | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { locale, t } = useI18n();
  const [side, setSide] = useState<"bottom" | "right">("bottom");

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const apply = () => setSide(mq.matches ? "right" : "bottom");
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  const region = place ? REGION_MAP[place.regionId] : null;

  return (
    <Sheet
      open={open && !!place}
      onOpenChange={(next) => onOpenChange(next)}
    >
      {place && region && (
        <SheetContent
          side={side}
          className="w-full gap-0 overflow-y-auto p-0 opacity-100 data-starting-style:opacity-100 sm:max-w-md"
        >
        <PlaceArt place={place} className="h-36 w-full sm:h-44" />
        <SheetHeader className="gap-2 p-5">
          <p className="text-xs font-medium tracking-wide text-primary uppercase">
            {loc(region.name, locale)}
          </p>
          <SheetTitle className="font-heading text-xl">
            {loc(place.name, locale)}
          </SheetTitle>
          <SheetDescription className="text-sm leading-relaxed">
            {loc(place.summary, locale)}
          </SheetDescription>
          <div className="flex flex-wrap gap-1 pt-1">
            {place.categories.map((category) => (
              <CategoryBadge key={category} category={category} />
            ))}
          </div>
        </SheetHeader>
        <div className="space-y-4 px-5 pb-6">
          <p className="text-sm leading-relaxed text-foreground/90">
            {loc(place.description, locale)}
          </p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-lg bg-muted/70 p-3">
              <p className="text-[0.7rem] text-muted-foreground">
                {t("hiddenness")}
              </p>
              <p className="mt-1 font-medium">
                {hiddennessLabel(place.hiddenness, locale)}
              </p>
            </div>
            <div className="rounded-lg bg-muted/70 p-3">
              <p className="text-[0.7rem] text-muted-foreground">
                {t("duration")}
              </p>
              <p className="mt-1 flex items-center gap-1 font-medium">
                <Clock className="size-3.5" />
                {place.durationHours}
                {t("hours")}
              </p>
            </div>
          </div>
          <div className="rounded-lg border border-border bg-card p-3">
            <p className="flex items-center gap-1.5 text-xs font-medium text-primary">
              <Lightbulb className="size-3.5" />
              {t("localTip")}
            </p>
            <p className="mt-1.5 text-sm leading-relaxed">
              {loc(place.tip, locale)}
            </p>
          </div>
          <dl className="space-y-2 text-sm">
            <div>
              <dt className="text-xs text-muted-foreground">{t("hoursLabel")}</dt>
              <dd>{loc(place.hours, locale)}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">{t("address")}</dt>
              <dd className="flex items-start gap-1">
                <MapPinned className="mt-0.5 size-3.5 shrink-0" />
                {loc(place.address, locale)}
              </dd>
            </div>
          </dl>
          <Link
            href={`/courses?seed=${place.id}`}
            className={cn(buttonVariants(), "w-full")}
          >
            {t("addToCourse")}
          </Link>
        </div>
      </SheetContent>
      )}
    </Sheet>
  );
}
