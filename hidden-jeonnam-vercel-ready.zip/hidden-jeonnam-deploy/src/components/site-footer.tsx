"use client";

import { useI18n } from "@/components/i18n-provider";

export function SiteFooter() {
  const { t } = useI18n();
  return (
    <footer className="border-t border-border/70 px-4 py-4 text-center text-[0.7rem] text-muted-foreground sm:px-6">
      {t("footer")}
    </footer>
  );
}
