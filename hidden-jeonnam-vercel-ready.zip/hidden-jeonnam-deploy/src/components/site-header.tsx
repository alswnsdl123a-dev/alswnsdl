"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Compass, Download, MapPinned } from "lucide-react";
import { useI18n } from "@/components/i18n-provider";
import { LOCALES, type Locale } from "@/lib/types";
import { LOCALE_META } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const pathname = usePathname();
  const { locale, setLocale, t } = useI18n();

  return (
    <header className="relative z-[200000] flex h-14 shrink-0 items-center justify-between gap-2 border-b border-border bg-background/95 px-3 backdrop-blur sm:gap-3 sm:px-5">
      <Link href="/" className="flex min-w-0 items-center gap-2">
        <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <MapPinned className="size-4" />
        </span>
        <span className="truncate font-serif text-lg tracking-tight">{t("brand")}</span>
      </Link>
      <nav className="flex shrink-0 items-center gap-1 sm:gap-2">
        <Link
          href="/"
          className={cn(
            "flex items-center gap-1.5 rounded-full px-2 py-1.5 text-sm sm:px-2.5",
            pathname === "/" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground",
          )}
        >
          <Compass className="size-4" />
          <span className="hidden sm:inline">{t("explore")}</span>
        </Link>
        <Link
          href="/courses"
          className={cn(
            "rounded-full px-2 py-1.5 text-sm sm:px-2.5",
            pathname.startsWith("/courses")
              ? "bg-primary/10 text-primary"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          {t("courses")}
        </Link>
        <Link
          href="/download"
          className={cn(
            "flex items-center gap-1.5 rounded-full px-2 py-1.5 text-sm sm:px-2.5",
            pathname.startsWith("/download")
              ? "bg-primary/10 text-primary"
              : "text-muted-foreground hover:text-foreground",
          )}
        >
          <Download className="size-4" />
          <span className="hidden md:inline">{t("download")}</span>
        </Link>
        <div className="ml-0.5 flex items-center gap-0.5 rounded-full border border-border bg-card p-0.5">
          {LOCALES.map((code) => (
            <LanguageButton
              key={code}
              code={code}
              active={locale === code}
              onSelect={setLocale}
            />
          ))}
        </div>
      </nav>
    </header>
  );
}

function LanguageButton({
  code,
  active,
  onSelect,
}: {
  code: Locale;
  active: boolean;
  onSelect: (locale: Locale) => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.preventDefault();
        event.stopPropagation();
        onSelect(code);
      }}
      className={cn(
        "relative z-[200001] cursor-pointer rounded-full px-1.5 py-1 text-[11px] font-medium leading-none sm:px-2.5 sm:text-xs",
        active
          ? "bg-primary text-primary-foreground"
          : "text-muted-foreground hover:bg-muted hover:text-foreground",
      )}
    >
      {LOCALE_META[code].native}
    </button>
  );
}
