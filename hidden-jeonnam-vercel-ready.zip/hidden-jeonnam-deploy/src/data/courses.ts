import { L } from "@/lib/i18n";
import type { FeaturedCourse } from "@/lib/types";

export const FEATURED_COURSES: FeaturedCourse[] = [
  {
    id: "tea-and-forest",
    title: L("녹차와 편백, 이틀", "Tea and Cypress, Two Days", "绿茶与扁柏，两天", "緑茶とヒノキ、二日"),
    summary: L(
      "보성 산촌에서 장흥·장성 숲으로. 차 향과 피톤치드가 이어지는 남도 중남부 코스.",
      "From a Boseong hill village into Jangheung and Jangseong woods—tea scent into phytoncide.",
      "从宝城山村走到长兴、长城的森林。茶香连着芬多精。",
      "宝城の山村から長興・長城の森へ。茶の香りがフィトンチッドにつながるコース。",
    ),
    daysLabel: L("2일", "2 days", "2天", "2日"),
    categories: ["nature", "experience"],
    regionIds: ["boseong", "jangheung", "jangseong"],
    days: [
      {
        day: 1,
        theme: L("보성에서 차를 마시고 갯벌을 본다", "Tea in Boseong, mudflat at dusk", "在宝城喝茶，看晚潮泥滩", "宝城で茶を飲み、干潟を見る"),
        placeIds: ["boseong-jeamsan", "boseong-yulpo"],
      },
      {
        day: 2,
        theme: L("편백 두 숲을 잇다", "Two cypress forests", "连起两片扁柏林", "二つのヒノキの森をつなぐ"),
        placeIds: ["jangheung-woodland", "jangseong-chuknyeong"],
      },
    ],
  },
  {
    id: "island-time",
    title: L("섬의 시간, 사흘", "Island Time, Three Days", "岛屿的时间，三天", "島の時間、三日"),
    summary: L(
      "신안 염전에서 진도 낙조, 완도 돌담까지. 배편을 믿고 걷는 서남해 섬 여행.",
      "Sinan salt pans, a Jindo sunset, Wando stone walls—an island trip that trusts the ferry.",
      "从新安盐田到珍岛落日、莞岛石墙。相信船班的西南海岛旅行。",
      "新安の塩田から珍島の落日、莞島の石垣まで。船便を信じて歩く西南海の島旅。",
    ),
    daysLabel: L("3일", "3 days", "3天", "3日"),
    categories: ["nature", "experience", "history"],
    regionIds: ["sinan", "jindo", "wando"],
    days: [
      {
        day: 1,
        theme: L("증도에서 해가 소금 위에 진다", "Sun sets on Jeungdo salt", "曾岛的太阳落在盐上", "曾島で日が塩の上に沈む"),
        placeIds: ["sinan-jeungdo"],
      },
      {
        day: 2,
        theme: L("진도의 그림과 노을", "Jindo paint and dusk", "珍岛的画与晚霞", "珍島の絵と夕焼け"),
        placeIds: ["jindo-unlimsanbang", "jindo-seobang"],
      },
      {
        day: 3,
        theme: L("청산도 슬로길을 새벽부터", "Cheongsando slow road from dawn", "从黎明走青山岛慢路", "青山島スローロードを夜明けから"),
        placeIds: ["wando-cheongsando"],
      },
    ],
  },
  {
    id: "namdo-table",
    title: L("남도 밥상, 이틀", "A Namdo Table, Two Days", "南道饭桌，两天", "南道の食卓、二日"),
    summary: L(
      "목포 앞바다, 나주 홍어, 강진 한정식. 맛으로 전남을 가로지르는 코스.",
      "Mokpo’s shore, Naju skate, Gangjin hanjeongsik—crossing Jeonnam by taste.",
      "木浦近海、罗州鳐鱼、康津韩定食。用味道横穿全南。",
      "木浦の沖、羅州のエイ、康津の韓定食。味で全南を横断するコース。",
    ),
    daysLabel: L("2일", "2 days", "2天", "2日"),
    categories: ["food", "history"],
    regionIds: ["mokpo", "naju", "gangjin"],
    days: [
      {
        day: 1,
        theme: L("목포 해안을 걷고 나주에서 먹다", "Walk Mokpo, eat in Naju", "走木浦海岸，在罗州吃饭", "木浦の海岸を歩き、羅州で食べる"),
        placeIds: ["mokpo-gathawi", "naju-yeongsanpo"],
      },
      {
        day: 2,
        theme: L("강진에서 책을 읽고 다리를 걷다", "Read in Gangjin, walk the bridges", "在康津读书，走过吊桥", "康津で本を読み、橋を歩く"),
        placeIds: ["gangjin-dasan", "gangjin-gaudo"],
      },
    ],
  },
  {
    id: "temple-trail",
    title: L("산사 순례, 사흘", "Temple Trail, Three Days", "山寺巡礼，三天", "山寺巡礼、三日"),
    summary: L(
      "구례 암자, 해남 총림, 화순 석불. 절이 숲과 바위를 빌려 지은 자리만 잇습니다.",
      "A Gurye hermitage, Haenam monastery, Hwasun stone Buddhas—temples that borrowed forest and rock.",
      "求礼庵子、海南丛林、和顺石佛。只连接借森林与岩石而建的寺院。",
      "求礼の庵、海南の叢林、和順の石仏。森と岩を借りて建った場所だけをつなぎます。",
    ),
    daysLabel: L("3일", "3 days", "3天", "3日"),
    categories: ["history", "nature"],
    regionIds: ["gurye", "haenam", "hwasun"],
    days: [
      {
        day: 1,
        theme: L("섬진강 위 사성암", "Saseongam above the Seomjin", "蟾津江上的四圣庵", "蟾津江の上の四聖庵"),
        placeIds: ["gurye-saseongam", "gurye-piagol"],
      },
      {
        day: 2,
        theme: L("두륜산 아래 하루", "A day under Duryunsan", "头轮山下的一天", "頭輪山の下の一日"),
        placeIds: ["haenam-daeheungsa", "haenam-songho"],
      },
      {
        day: 3,
        theme: L("운주사 골짜기의 물음", "Questions in Unjusa valley", "云住寺山谷里的提问", "雲住寺の谷の問い"),
        placeIds: ["hwasun-unjusa", "hwasun-jeokbyeok"],
      },
    ],
  },
  {
    id: "river-slow",
    title: L("강과 숲, 이틀", "River and Forest, Two Days", "江与森林，两天", "川と森、二日"),
    summary: L(
      "담양 돌담, 곡성 계곡, 광양 재첩국. 죽녹원 줄을 피해 강줄기를 따라갑니다.",
      "Damyang walls, a Gokseong creek, Gwangyang clam soup—following the river past Jungnogwon queues.",
      "潭阳石墙、谷城溪谷、光阳蚬子汤。躲开竹绿院的队伍，沿江走。",
      "潭陽の石垣、谷城の渓、光陽のシジミ汁。竹緑院の列を外して川筋をたどります。",
    ),
    daysLabel: L("2일", "2 days", "2天", "2日"),
    categories: ["nature", "food", "experience"],
    regionIds: ["damyang", "gokseong", "gwangyang"],
    days: [
      {
        day: 1,
        theme: L("창평에서 천천히, 곡성에서 물소리", "Slow Changpyeong, Gokseong water", "在昌平慢慢走，在谷城听水", "昌平でゆっくり、谷城で水音"),
        placeIds: ["damyang-changpyeong", "gokseong-dorimsa"],
      },
      {
        day: 2,
        theme: L("섬진강 나루의 아침", "Morning at the Seomjin ferry", "蟾津江渡口的早晨", "蟾津江の渡しの朝"),
        placeIds: ["gwangyang-seomjin", "gwangyang-baegunsan"],
      },
    ],
  },
];
