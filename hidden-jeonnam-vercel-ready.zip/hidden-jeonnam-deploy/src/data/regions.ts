import type { Localized, RegionId } from "@/lib/types";

export type Region = {
  id: RegionId;
  name: Localized;
  cluster: "west" | "center" | "east" | "south";
  neighbors: RegionId[];
};

export const REGIONS: Region[] = [
  {
    id: "mokpo",
    name: { ko: "목포시", en: "Mokpo", zh: "木浦市", ja: "木浦市" },
    cluster: "west",
    neighbors: ["muan", "yeongam", "haenam", "sinan"],
  },
  {
    id: "yeosu",
    name: { ko: "여수시", en: "Yeosu", zh: "丽水市", ja: "麗水市" },
    cluster: "east",
    neighbors: ["suncheon", "gwangyang", "goheung"],
  },
  {
    id: "suncheon",
    name: { ko: "순천시", en: "Suncheon", zh: "顺天市", ja: "順天市" },
    cluster: "east",
    neighbors: ["yeosu", "gwangyang", "gokseong", "gurye", "boseong"],
  },
  {
    id: "naju",
    name: { ko: "나주시", en: "Naju", zh: "罗州市", ja: "羅州市" },
    cluster: "center",
    neighbors: ["hwasun", "yeongam", "hampyeong", "jangseong"],
  },
  {
    id: "gwangyang",
    name: { ko: "광양시", en: "Gwangyang", zh: "光阳市", ja: "光陽市" },
    cluster: "east",
    neighbors: ["yeosu", "suncheon", "gurye"],
  },
  {
    id: "damyang",
    name: { ko: "담양군", en: "Damyang", zh: "潭阳郡", ja: "潭陽郡" },
    cluster: "center",
    neighbors: ["jangseong", "gokseong", "hwasun"],
  },
  {
    id: "gokseong",
    name: { ko: "곡성군", en: "Gokseong", zh: "谷城郡", ja: "谷城郡" },
    cluster: "east",
    neighbors: ["damyang", "gurye", "suncheon", "hwasun"],
  },
  {
    id: "gurye",
    name: { ko: "구례군", en: "Gurye", zh: "求礼郡", ja: "求礼郡" },
    cluster: "east",
    neighbors: ["gokseong", "gwangyang", "suncheon"],
  },
  {
    id: "goheung",
    name: { ko: "고흥군", en: "Goheung", zh: "高兴郡", ja: "高興郡" },
    cluster: "east",
    neighbors: ["yeosu", "boseong"],
  },
  {
    id: "boseong",
    name: { ko: "보성군", en: "Boseong", zh: "宝城郡", ja: "宝城郡" },
    cluster: "south",
    neighbors: ["goheung", "suncheon", "jangheung", "hwasun"],
  },
  {
    id: "hwasun",
    name: { ko: "화순군", en: "Hwasun", zh: "和顺郡", ja: "和順郡" },
    cluster: "center",
    neighbors: ["naju", "damyang", "boseong", "jangheung"],
  },
  {
    id: "jangheung",
    name: { ko: "장흥군", en: "Jangheung", zh: "长兴郡", ja: "長興郡" },
    cluster: "south",
    neighbors: ["boseong", "hwasun", "gangjin", "wando"],
  },
  {
    id: "gangjin",
    name: { ko: "강진군", en: "Gangjin", zh: "康津郡", ja: "康津郡" },
    cluster: "south",
    neighbors: ["jangheung", "haenam", "yeongam", "wando"],
  },
  {
    id: "haenam",
    name: { ko: "해남군", en: "Haenam", zh: "海南郡", ja: "海南郡" },
    cluster: "south",
    neighbors: ["gangjin", "yeongam", "mokpo", "jindo", "wando"],
  },
  {
    id: "yeongam",
    name: { ko: "영암군", en: "Yeongam", zh: "灵岩郡", ja: "霊岩郡" },
    cluster: "center",
    neighbors: ["naju", "mokpo", "haenam", "gangjin", "muan"],
  },
  {
    id: "muan",
    name: { ko: "무안군", en: "Muan", zh: "务安郡", ja: "務安郡" },
    cluster: "west",
    neighbors: ["mokpo", "hampyeong", "yeongam", "sinan"],
  },
  {
    id: "hampyeong",
    name: { ko: "함평군", en: "Hampyeong", zh: "咸平郡", ja: "咸平郡" },
    cluster: "west",
    neighbors: ["muan", "naju", "yeonggwang", "jangseong"],
  },
  {
    id: "yeonggwang",
    name: { ko: "영광군", en: "Yeonggwang", zh: "灵光郡", ja: "栄光郡" },
    cluster: "west",
    neighbors: ["hampyeong", "jangseong"],
  },
  {
    id: "jangseong",
    name: { ko: "장성군", en: "Jangseong", zh: "长城郡", ja: "長城郡" },
    cluster: "center",
    neighbors: ["damyang", "naju", "hampyeong", "yeonggwang"],
  },
  {
    id: "wando",
    name: { ko: "완도군", en: "Wando", zh: "莞岛郡", ja: "莞島郡" },
    cluster: "south",
    neighbors: ["jangheung", "gangjin", "haenam", "jindo"],
  },
  {
    id: "jindo",
    name: { ko: "진도군", en: "Jindo", zh: "珍岛郡", ja: "珍島郡" },
    cluster: "south",
    neighbors: ["haenam", "wando", "sinan"],
  },
  {
    id: "sinan",
    name: { ko: "신안군", en: "Sinan", zh: "新安郡", ja: "新安郡" },
    cluster: "west",
    neighbors: ["mokpo", "muan", "jindo"],
  },
];

export const REGION_MAP = Object.fromEntries(
  REGIONS.map((region) => [region.id, region]),
) as Record<RegionId, Region>;

export const JEONNAM_CENTER = { lat: 34.82, lng: 126.92 };
