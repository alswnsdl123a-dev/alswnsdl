import { PLACES } from "@/data/places";
import { REGION_MAP } from "@/data/regions";
import { L } from "@/lib/i18n";
import type { Localized, Place } from "@/lib/types";

export type GalleryItem = {
  src: string;
  alt: Localized;
  placeId: string;
  video?: boolean;
  youtubeId?: string;
  youtubeQuery?: string;
  objectPosition?: string;
};

export type BlogReview = {
  id: string;
  author: string;
  bio: Localized;
  title: Localized;
  excerpt: Localized;
  date: Localized;
  photoCount: number;
  thumb: string;
  avatar: string;
  url: string;
};

export type VisitorReview = {
  id: string;
  author: string;
  date: string;
  visit: number;
  body: Localized;
  tags: { label: Localized; emoji: string }[];
  extraTags: number;
  photoCount: number;
  thumb: string;
  avatar: string;
};

const BLOGGERS = [
  { author: "느린남도", bio: L("전남만 걷는 중", "Walking Jeonnam slowly", "只走全南", "全南だけを歩いている") },
  { author: "섬바람기록", bio: L("배 타고 섬 모음", "Island hopper", "坐船收集岛屿", "船で島を集める") },
  { author: "절집오후", bio: L("산사 사진", "Temple afternoons", "山寺照片", "山寺の写真") },
  { author: "갯벌한끼", bio: L("포구 맛집만", "Harbor tables", "只找浦口美食", "浦の店だけ") },
  { author: "임도주말", bio: L("숲길 드라이브", "Forest-road weekends", "林道周末", "林道の週末") },
];

const VISITORS = ["별****", "초이2030", "달빛산책", "gom****", "느린여행자", "sci****"];

function hash(value: string) {
  let total = 0;
  for (let i = 0; i < value.length; i += 1) {
    total = (total * 33 + value.charCodeAt(i)) >>> 0;
  }
  return total;
}

function pick<T>(list: T[], seed: number) {
  return list[seed % list.length];
}

function naverBlogs(query: string) {
  return `https://search.naver.com/search.naver?ssc=tab.blog.all&query=${encodeURIComponent(query)}`;
}

const YOUTUBE_ID: Partial<Record<string, string[]>> = {
  "yeosu-geumodo": ["NcgIXbyH8GU"],
};

const BLOG_URL: Partial<Record<string, string[]>> = {
  "yeosu-geumodo": [
    "https://wjpark2002.tistory.com/209410",
    "https://mmg121.tistory.com/158",
    "https://electee.tistory.com/1959",
  ],
  "suncheon-seonamsa": [
    "https://view.mk.co.kr/trip-food/article/264190/",
    "https://www.hiking-beginner.com/trail/jogyesan-seonamsa",
    "https://www.traveltimesnews.com/news/articleView.html?idxno=2752",
  ],
  "yeosu-geomundo": [
    "https://www.telltrip.com/domestic-travel/geomundo-island-2026-marine-tourism-yeosu/",
  ],
  "wando-cheongsando": ["https://micropsjj.tistory.com/17041389"],
};

const CROWD = {
  1: L("주말엔 사람이 좀 있어요. 평일 오전이 낫습니다.", "Weekends get a few people. Weekday mornings are kinder.", "周末会有些人。平日上午更好。", "週末は人が少しいます。平日の午前が楽です。"),
  2: L("한낮에도 한산했습니다. 포토 스팟만 잠깐 붐벼요.", "Still quiet at midday. Only the photo stop fills briefly.", "中午也很清静。只有拍照点会短暂拥挤。", "昼間も静かでした。写真スポットだけが少し混みます。"),
  3: L("거의 저희뿐이었어요. 안내판만 보고 걸었습니다.", "Almost nobody else. We walked by the signs alone.", "几乎只有我们。看着指示牌走完。", "ほとんど私たちだけでした。案内板だけを見て歩きました。"),
} as const;

function firstSentence(text: string) {
  const match = text.match(/.*?[다요임][\.]/);
  return match ? match[0] : text.slice(0, 60);
}

export function youtubeEmbedSrc(item: GalleryItem) {
  if (item.youtubeId) {
    return `https://www.youtube.com/embed/${item.youtubeId}?autoplay=1&rel=0`;
  }
  const query = item.youtubeQuery ?? "전남 여행";
  return `https://www.youtube.com/embed?autoplay=1&rel=0&listType=search&list=${encodeURIComponent(query)}`;
}

export function galleryFor(place: Place): GalleryItem[] {
  const sameRegion = PLACES.filter(
    (item) => item.regionId === place.regionId && item.id !== place.id,
  );
  const positions = ["50% 50%", "50% 20%", "20% 50%", "80% 40%", "40% 80%", "60% 30%"];
  const videos = YOUTUBE_ID[place.id] ?? [];
  const query = `전남 ${place.name.ko} 여행`;

  return Array.from({ length: 9 }, (_, index) => {
    const isVideo = index === 1 || index === 4 || index === 7;
    if (isVideo) {
      const youtubeId = videos[Math.floor(index / 3) % Math.max(videos.length, 1)];
      return {
        src: `/places/${place.id}.jpg`,
        alt: L(
          `${place.name.ko} 방문자 영상`,
          `${place.name.en} visitor video`,
          `${place.name.zh} 访客视频`,
          `${place.name.ja} の訪問者動画`,
        ),
        placeId: place.id,
        video: true,
        youtubeId: videos.length ? youtubeId : undefined,
        youtubeQuery: query,
        objectPosition: "50% 40%",
      };
    }
    const photoIndex = [0, 2, 3, 5, 6, 8].indexOf(index);
    const neighbor = sameRegion[photoIndex % Math.max(sameRegion.length, 1)];
    const useNeighbor = photoIndex > 3 && neighbor;
    const source = useNeighbor ? neighbor : place;
    return {
      src: `/places/${source.id}.jpg`,
      alt: L(
        `${source.name.ko}에서 찍은 컷`,
        `Shot at ${source.name.en}`,
        `在${source.name.zh}拍的`,
        `${source.name.ja}で撮ったカット`,
      ),
      placeId: source.id,
      objectPosition: positions[photoIndex] ?? "50% 50%",
    };
  });
}

export function blogReviewsFor(place: Place): BlogReview[] {
  const seed = hash(place.id);
  const region = REGION_MAP[place.regionId];
  const name = place.name;
  const urls = BLOG_URL[place.id] ?? [];
  const scene = firstSentence(place.description.ko);
  const sceneEn = firstSentence(place.description.en);
  const crowd = CROWD[place.hiddenness];

  const posts: Omit<BlogReview, "id" | "author" | "bio" | "date" | "photoCount" | "thumb" | "avatar">[] =
    [
      {
        title: L(
          `${name.ko} 가는 길만 정리하면`,
          `Just the way to ${name.en}`,
          `只整理去${name.zh}的路`,
          `${name.ja}への行き方だけまとめると`,
        ),
        excerpt: L(
          `${region.name.ko} ${locAddress(place)}. 현지 팁은 이렇습니다. ${place.tip.ko} 이용 시간은 ${place.hours.ko}.`,
          `${region.name.en}. Local note: ${place.tip.en} Hours: ${place.hours.en}.`,
          `${region.name.zh} ${place.address.zh}。当地提示：${place.tip.zh} 开放时间：${place.hours.zh}。`,
          `${region.name.ja} ${place.address.ja}。現地のヒントはこうです。${place.tip.ja} 利用時間は${place.hours.ja}。`,
        ),
        url: urls[0] ?? naverBlogs(`${name.ko} 가는 법 후기`),
      },
      {
        title: L(
          `${name.ko}에서 실제로 본 것`,
          `What ${name.en} actually looks like`,
          `在${name.zh}实际看到的`,
          `${name.ja}で実際に見たこと`,
        ),
        excerpt: L(
          `${scene} ${place.summary.ko} 머무는 시간은 대략 ${place.durationHours}시간이면 충분했습니다.`,
          `${sceneEn} ${place.summary.en} About ${place.durationHours} hours is enough.`,
          `${firstSentence(place.description.zh)} ${place.summary.zh} 停留大约 ${place.durationHours} 小时就够。`,
          `${firstSentence(place.description.ja)} ${place.summary.ja} 滞在はおよそ${place.durationHours}時間で足りました。`,
        ),
        url: urls[1] ?? naverBlogs(`${name.ko} 여행 코스 후기`),
      },
      {
        title: L(
          `사람 적은 시간에 간 ${name.ko}`,
          `${name.en} when it is quiet`,
          `人少的时候去的${name.zh}`,
          `人が少ない時間に行った${name.ja}`,
        ),
        excerpt: L(
          `${crowd.ko} ${place.tip.ko.replace("하세요.", "했어요.").replace("세요.", "어요.")}`,
          `${crowd.en} ${place.tip.en}`,
          `${crowd.zh} ${place.tip.zh}`,
          `${crowd.ja} ${place.tip.ja}`,
        ),
        url: urls[2] ?? naverBlogs(`${name.ko} 한적한 시간 후기`),
      },
    ];

  return posts.map((post, index) => {
    const blogger = pick(BLOGGERS, seed + index);
    return {
      ...post,
      id: `${place.id}-blog-${index}`,
      author: blogger.author,
      bio: blogger.bio,
      date: L(
        ["3.1.일", "4.15.수", "5.8.금", "6.21.토", "9.12.토"][(seed + index) % 5],
        ["Mar 1", "Apr 15", "May 8", "Jun 21", "Sep 12"][(seed + index) % 5],
        ["3月1日", "4月15日", "5月8日", "6月21日", "9月12日"][(seed + index) % 5],
        ["3月1日", "4月15日", "5月8日", "6月21日", "9月12日"][(seed + index) % 5],
      ),
      photoCount: 8 + ((seed + index * 13) % 40),
      thumb: `/places/${place.id}.jpg`,
      avatar: `/places/${pick(PLACES, seed + index * 3).id}.jpg`,
    };
  });
}

function locAddress(place: Place) {
  return place.address.ko;
}

export function visitorReviewsFor(place: Place): VisitorReview[] {
  const seed = hash(`${place.id}-v`);
  const crowd = CROWD[place.hiddenness];
  const food = place.categories.includes("food");
  const walk = place.categories.includes("nature") || place.categories.includes("experience");

  const bodies: Localized[] = [
    L(
      `${place.hours.ko}에 맞춰 갔어요. ${place.tip.ko.replace("하세요.", "해서 편했어요.").replace("세요.", "었어요.")} ${crowd.ko}`,
      `Went around ${place.hours.en}. ${place.tip.en} ${crowd.en}`,
      `按${place.hours.zh}去的。${place.tip.zh} ${crowd.zh}`,
      `${place.hours.ja}に合わせて行きました。${place.tip.ja} ${crowd.ja}`,
    ),
    L(
      walk
        ? `걸어서 ${place.durationHours}시간 잡으니 여유가 있었어요. ${firstSentence(place.description.ko)}`
        : food
          ? `맛은 기대 이상. ${place.summary.ko} 줄은 길지 않았습니다.`
          : `${place.summary.ko} 설명문만 천천히 읽고 나왔어요.`,
      walk
        ? `${place.durationHours} hours on foot felt right. ${firstSentence(place.description.en)}`
        : food
          ? `Better than expected. ${place.summary.en} The line was short.`
          : `${place.summary.en} We just read the signs slowly.`,
      walk
        ? `步行按 ${place.durationHours} 小时算刚刚好。${firstSentence(place.description.zh)}`
        : food
          ? `味道比预期好。${place.summary.zh} 队伍不长。`
          : `${place.summary.zh} 慢慢把说明读完就出来了。`,
      walk
        ? `歩いて${place.durationHours}時間とると余裕がありました。${firstSentence(place.description.ja)}`
        : food
          ? `味は期待以上。${place.summary.ja} 列は長くありませんでした。`
          : `${place.summary.ja} 説明文だけゆっくり読んで出ました。`,
    ),
    L(
      `아쉬운 점은 그늘이 적고 바람이 세요. 그래도 ${place.name.ko}는 다시 오고 싶습니다. ${place.tip.ko}`,
      `Little shade and a stiff wind. Still, I would return to ${place.name.en}. ${place.tip.en}`,
      `不足是树荫少、风大。但还是想再来${place.name.zh}。${place.tip.zh}`,
      `惜しいのは日陰が少なく風が強いこと。それでも${place.name.ja}にはまた来たいです。${place.tip.ja}`,
    ),
  ];

  const tagSets = [
    [
      { emoji: "🌿", label: L("한적해요", "Quiet", "很清静", "静か") },
      { emoji: "📸", label: L("사진이 잘 나와요", "Photogenic", "很上镜", "写真映え") },
    ],
    [
      { emoji: "🚶", label: L("걷기 좋아요", "Good walk", "适合走", "歩きやすい") },
      { emoji: "🖼️", label: L("뷰가 좋아요", "Great view", "风景好", "眺めがいい") },
    ],
    [
      { emoji: "☕", label: L("쉬어가기 좋아요", "Nice rest stop", "适合歇脚", "休みやすい") },
      { emoji: "🌿", label: L("한적해요", "Quiet", "很清静", "静か") },
    ],
  ];

  return bodies.map((body, index) => ({
    id: `${place.id}-visit-${index}`,
    author: pick(VISITORS, seed + index),
    date: ["25.11.3", "25.9.18", "26.3.2", "25.12.24", "26.1.11"][(seed + index) % 5],
    visit: 1 + ((seed + index) % 4),
    body,
    tags: tagSets[index],
    extraTags: 2 + ((seed + index) % 4),
    photoCount: 1 + ((seed + index * 9) % 8),
    thumb: `/places/${place.id}.jpg`,
    avatar: `/places/${pick(PLACES, seed + index * 11).id}.jpg`,
  }));
}

export function reviewCounts(place: Place) {
  const seed = hash(place.id);
  return {
    blogs: 18 + (seed % 40),
    visitors: 24 + (seed % 55),
    photos: 36 + (seed % 80),
  };
}
