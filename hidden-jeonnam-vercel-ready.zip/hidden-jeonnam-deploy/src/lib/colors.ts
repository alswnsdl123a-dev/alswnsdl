import type { Category } from "@/lib/types";

export const CATEGORY_COLORS: Record<Category, string> = {
  nature: "#3d6b4f",
  food: "#c45c26",
  history: "#6b5344",
  experience: "#2f6f7e",
};

export const CATEGORY_SOFT: Record<Category, string> = {
  nature: "oklch(0.93 0.04 150)",
  food: "oklch(0.94 0.04 55)",
  history: "oklch(0.93 0.02 70)",
  experience: "oklch(0.93 0.03 210)",
};

export function primaryCategory(categories: Category[]): Category {
  return categories[0] ?? "nature";
}
