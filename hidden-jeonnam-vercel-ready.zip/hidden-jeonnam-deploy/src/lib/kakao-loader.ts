const SDK_ID = "kakao-maps-sdk";

let loadPromise: Promise<typeof kakao> | null = null;

export function getKakaoJsKey() {
  return process.env.NEXT_PUBLIC_KAKAO_JS_KEY?.trim() ?? "";
}

function mapsReady() {
  return Boolean(window.kakao?.maps?.LatLng);
}

export function loadKakaoMaps(): Promise<typeof kakao> {
  const appKey = getKakaoJsKey();
  if (!appKey) {
    return Promise.reject(new Error("missing-kakao-key"));
  }
  if (typeof window === "undefined") {
    return Promise.reject(new Error("window-undefined"));
  }
  if (mapsReady()) {
    return Promise.resolve(window.kakao);
  }
  if (loadPromise) return loadPromise;

  loadPromise = new Promise((resolve, reject) => {
    const succeed = () => resolve(window.kakao);
    const fail = (error: Error) => {
      loadPromise = null;
      reject(error);
    };

    const finish = () => {
      if (mapsReady()) {
        succeed();
        return;
      }
      if (!window.kakao?.maps?.load) {
        fail(new Error("kakao-maps-unavailable"));
        return;
      }
      window.kakao.maps.load(() => {
        if (mapsReady()) succeed();
        else fail(new Error("kakao-maps-unavailable"));
      });
    };

    const existing = document.getElementById(SDK_ID) as HTMLScriptElement | null;
    if (existing) {
      existing.addEventListener("load", finish, { once: true });
      existing.addEventListener(
        "error",
        () => fail(new Error("kakao-sdk-load-failed")),
        { once: true },
      );
      if (window.kakao?.maps) finish();
      return;
    }

    const script = document.createElement("script");
    script.id = SDK_ID;
    script.async = true;
    script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${encodeURIComponent(appKey)}&autoload=false&libraries=services`;
    script.onload = finish;
    script.onerror = () => fail(new Error("kakao-sdk-load-failed"));
    document.head.appendChild(script);
  });

  return loadPromise;
}
