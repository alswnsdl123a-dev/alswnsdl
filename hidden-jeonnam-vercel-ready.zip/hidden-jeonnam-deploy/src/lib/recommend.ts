import { REGION_MAP } from "@/data/regions";
import { PLACES } from "@/data/places";
import type {
  Category,
  GeneratedCourse,
  Localized,
  Place,
  RegionId,
} from "@/lib/types";

const ALL_CATEGORIES: Category[] = ["nature", "food", "history", "experience"];

function distanceKm(a: Place, b: Place) {
  const toRad = (n: number) => (n * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function scorePlace(place: Place, categories: Category[]) {
  const overlap = place.categories.filter((c) => categories.includes(c)).length;
  return overlap * 3 + place.hiddenness * 2;
}

function nearestChain(start: Place, rest: Place[]) {
  const ordered: Place[] = [start];
  const leftover = [...rest];
  while (leftover.length) {
    const current = ordered[ordered.length - 1];
    leftover.sort((a, b) => distanceKm(current, a) - distanceKm(current, b));
    ordered.push(leftover.shift()!);
  }
  return ordered;
}

function splitDays(places: Place[], days: number) {
  const buckets: Place[][] = Array.from({ length: days }, () => []);
  const hours = Array.from({ length: days }, () => 0);
  for (const place of places) {
    let best = 0;
    for (let i = 1; i < days; i++) {
      if (hours[i] < hours[best]) best = i;
      else if (hours[i] === hours[best] && buckets[i].length < buckets[best].length) {
        best = i;
      }
    }
    if (hours[best] + place.durationHours > 10 && buckets.some((b) => b.length === 0)) {
      const empty = hours.findIndex((_, i) => buckets[i].length === 0);
      if (empty >= 0) best = empty;
    }
    buckets[best].push(place);
    hours[best] += place.durationHours;
  }
  return buckets
    .map((dayPlaces) =>
      dayPlaces.length <= 1 ? dayPlaces : nearestChain(dayPlaces[0], dayPlaces.slice(1)),
    )
    .map((dayPlaces, index) => ({ day: index + 1, places: dayPlaces }));
}

function themeFor(places: Place[]): Localized {
  const counts: Record<Category, number> = {
    nature: 0,
    food: 0,
    history: 0,
    experience: 0,
  };
  for (const place of places) {
    for (const category of place.categories) counts[category] += 1;
  }
  const top = (Object.entries(counts) as [Category, number][]).sort(
    (a, b) => b[1] - a[1],
  )[0][0];
  const themes: Record<Category, Localized> = {
    nature: { ko: "바람과 물가를 따라", en: "Along wind and water", zh: "沿着风和水边", ja: "風と水際をたどって" },
    food: { ko: "남도 밥상을 따라", en: "Following a Namdo table", zh: "跟着南道饭桌走", ja: "南道の食卓をたどって" },
    history: { ko: "옛길이 남는 자리", en: "Where old paths remain", zh: "旧路还在的地方", ja: "古い道が残る場所" },
    experience: { ko: "손과 발로 머무는 날", en: "A day for hands and feet", zh: "用手和脚停留的一天", ja: "手と足でとどまる日" },
  };
  return themes[top];
}

export function recommendCourse(opts: {
  categories: Category[];
  regionId: RegionId | "all";
  days: 1 | 2 | 3;
}): GeneratedCourse | null {
  const categories = opts.categories.length ? opts.categories : ALL_CATEGORIES;
  let pool = PLACES.filter((place) =>
    place.categories.some((category) => categories.includes(category)),
  );

  if (opts.regionId !== "all") {
    const region = REGION_MAP[opts.regionId];
    const nearby = new Set<RegionId>([region.id, ...region.neighbors]);
    const local = pool.filter((place) => nearby.has(place.regionId));
    if (local.length >= opts.days + 1) pool = local;
  }

  if (!pool.length) return null;

  const ranked = [...pool].sort(
    (a, b) => scorePlace(b, categories) - scorePlace(a, categories),
  );
  const target = Math.min(pool.length, opts.days * 3);
  const picked: Place[] = [];
  for (const candidate of ranked) {
    if (picked.length >= target) break;
    const tooClose = picked.some((place) => distanceKm(place, candidate) < 3);
    if (tooClose && picked.length + (ranked.length - ranked.indexOf(candidate)) > target) {
      continue;
    }
    picked.push(candidate);
  }

  if (!picked.length) return null;

  const ordered = nearestChain(picked[0], picked.slice(1));
  const days = splitDays(ordered, opts.days).filter((day) => day.places.length);

  const regionNamesKo =
    opts.regionId === "all"
      ? "전남 곳곳"
      : REGION_MAP[opts.regionId].name.ko;
  const regionNamesEn =
    opts.regionId === "all" ? "across Jeonnam" : REGION_MAP[opts.regionId].name.en;

  const regionNamesZh =
    opts.regionId === "all" ? "全罗南道各地" : REGION_MAP[opts.regionId].name.zh;
  const regionNamesJa =
    opts.regionId === "all" ? "全羅南道各地" : REGION_MAP[opts.regionId].name.ja;
  const stopCount = days.reduce((n, d) => n + d.places.length, 0);

  return {
    title: {
      ko: `${regionNamesKo} ${opts.days}일 숨은 길`,
      en: `${opts.days}-day hidden path ${regionNamesEn}`,
      zh: `${regionNamesZh} ${opts.days}日隐秘之路`,
      ja: `${regionNamesJa} ${opts.days}日の隠れた道`,
    },
    summary: {
      ko: `선택한 취향에 맞춰 ${stopCount}곳을 거리와 체류 시간 순으로 이었습니다.`,
      en: `A ${stopCount}-stop route ordered by distance and time for your tastes.`,
      zh: `按你的喜好，把 ${stopCount} 处按距离和停留时间串了起来。`,
      ja: `選んだ好みに合わせ、${stopCount}か所を距離と滞在時間でつなぎました。`,
    },
    days: days.map((day) => ({
      ...day,
      theme: themeFor(day.places),
    })),
  };
}
