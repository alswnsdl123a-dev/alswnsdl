export type Locale = "ko" | "en" | "zh" | "ja";

export const LOCALES: Locale[] = ["ko", "en", "zh", "ja"];

export type Localized = {
  ko: string;
  en: string;
  zh: string;
  ja: string;
};

export type Bilingual = {
  ko: string;
  en: string;
};

export type Category = "nature" | "food" | "history" | "experience";

export type RegionId =
  | "mokpo"
  | "yeosu"
  | "suncheon"
  | "naju"
  | "gwangyang"
  | "damyang"
  | "gokseong"
  | "gurye"
  | "goheung"
  | "boseong"
  | "hwasun"
  | "jangheung"
  | "gangjin"
  | "haenam"
  | "yeongam"
  | "muan"
  | "hampyeong"
  | "yeonggwang"
  | "jangseong"
  | "wando"
  | "jindo"
  | "sinan";

export type Place = {
  id: string;
  regionId: RegionId;
  lat: number;
  lng: number;
  categories: Category[];
  hiddenness: 1 | 2 | 3;
  durationHours: number;
  name: Localized;
  summary: Localized;
  description: Localized;
  tip: Localized;
  hours: Localized;
  address: Localized;
};

export type CourseDay = {
  day: number;
  theme: Localized;
  placeIds: string[];
};

export type FeaturedCourse = {
  id: string;
  title: Localized;
  summary: Localized;
  daysLabel: Localized;
  categories: Category[];
  regionIds: RegionId[];
  days: CourseDay[];
};

export type GeneratedCourse = {
  title: Localized;
  summary: Localized;
  days: {
    day: number;
    theme: Localized;
    places: Place[];
  }[];
};
