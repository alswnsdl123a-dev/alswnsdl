/// <reference types="kakao.maps.d.ts" />

export {};

declare global {
  interface Window {
    kakao: typeof kakao;
  }
}
